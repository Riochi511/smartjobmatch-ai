from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

print("1. Starting imports...")

print("2. Importing jobs...")
from app.api.jobs import router as jobs_router

print("3. Importing resumes...")
from app.api.resumes import router as resume_router

print("4. Importing career coach...")
from app.api.career_coach import router as career_router

print("5. Imports complete")

app = FastAPI(
    title="SmartJob AI",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

print("6. Registering routes...")

app.include_router(jobs_router)
app.include_router(resume_router)
app.include_router(career_router)

print("7. Startup finished")

@app.get("/")
def root():
    return {
        "status": "running"
    }