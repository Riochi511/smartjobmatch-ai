def load_jobs(self):

    try:

        self._ensure_file_exists()

        df = pd.read_csv(self.csv_path)

        print("=" * 60)
        print(f"Total jobs loaded: {len(df):,}")
        print("\nExtracting required skills...")
        print("=" * 60)

        jobs = df.to_dict(
            orient="records"
        )

        for i, job in enumerate(jobs, start=1):

            if i % 1000 == 0:
                print(f"Processed {i:,} jobs...")

            description = str(
                job.get("description", "")
            )

            extracted = JobSkillExtractor.extract(
                description
            )

            job["required_skills"] = extracted[
                "required_skills"
            ]

            job["required_skill_categories"] = extracted[
                "required_skill_categories"
            ]

        print("=" * 60)
        print(
            f"Finished processing {len(jobs):,} jobs."
        )

        print("\nFirst processed job:\n")
        print(jobs[0])

        print("=" * 60)

        return jobs

    except FileNotFoundError:

        raise JobLoadingException(
            f"Job file '{self.csv_path}' was not found."
        )

    except Exception as e:

        raise JobLoadingException(
            f"Unable to load jobs: {str(e)}"
        )